## this program pulls out the ungapped blocks from LAGAN mfa file
##
## usage: python ./extract_lagan_blks.py <mfa_file> > output_file

import string
import sys
import commands
from align_lib import *

blks = get_lagan_blk_with_constraints(sys.argv[1],sys.argv[2],sys.argv[3])

pb_b1 = -1
pb_e1 = -1
pb_b2 = -1
pb_e2 = -1

for blk in blks:
    tb_b1 = blk['b1']                                                      
    tb_e1 = blk['e1']
    tb_b2 = blk['b2']
    tb_e2 = blk['e2']

    #if blk['PID'] >= 70  and blk['len'] >= 10 and not((tb_b1-pb_e1 <= 500 and tb_b2-pb_e2 > 2000) or (tb_b1-pb_e1 > 2000 and tb_b2-pb_e2 <= 500)):
    if not((tb_b1-pb_e1 <= 500 and tb_b2-pb_e2 > 2000) or (tb_b1-pb_e1 > 2000 and tb_b2-pb_e2 <= 500)):
        print '(%d %d)=(%d %d) %.6f' % (blk['b1'],blk['e1'],blk['b2'],blk['e2'],blk['PID'])        
    pb_b1 = blk['b1']                                                     
    pb_e1 = blk['e1']
    pb_b2 = blk['b2']
    pb_e2 = blk['e2']

    
